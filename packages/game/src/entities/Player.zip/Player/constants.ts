export const machineId = "player";
