// Libraries
import { setup } from "xstate";
// Local level
import type { PlayerContext } from "./context";
import { machineId } from "./constants";
import { PlayerStates } from "./states";
import { PlayerTargets } from "./targets";
import { type PlayerEvent, type PlayerOutEvent, PlayerEvents } from "./events";

export const playerMachine = setup({
  types: {
    context: {} as PlayerContext,
    events: {} as PlayerEvent,
    emitted: {} as PlayerOutEvent,
  },
}).createMachine({
  id: "player",
  context: { cards: [], turnCount: 0 },
  initial: "in-lobby",
  states: {
    ["in-lobby"]: {
      initial: "not-ready",
      states: {
        ["not-ready"]: {
          on: {
            ["CONFIRM_READINESS"]: {
              target: "#player.in-lobby.ready",
            },
          },
        },
        ["ready"]: {
          on: {
            ["CANCEL_READINESS"]: {
              target: "#player.in-lobby.not-ready",
            },
            ["GAME_STARTED"]: {
              target: "#player.in-game",
            },
          },
        },
      },
    },
    ["in-game"]: {
      on: { ["GAME_ENDED"]: { target: "#player.after-game" } },
    },
    ["after-game"]: { type: "final" },
  },
});
